-- Drop the index and table for spatial query result
DROP INDEX LocationIndex ON ItemLocation;
DROP TABLE IF EXISTS ItemLocation;

