Kyle Haacker, 904467146
Zach Bordofsky, 304443257

CS 144 - Project 3
Part B: Spatial Search

We use the MyISAM engine to create a MySQL table `ItemLocation` that contains the id and location (in `Point` format) of each item in our database. We create a spatial index on the `Point` column stored in our new table. We can make use of this index in queries by
using the MySQL `MBRContains` method. We can compare the set of points within the search
region with the set of points that match the basic keyword search, returning results that
only satisfy both conditions.

We tested our implementation by adding test cases / switching the test inputs in the file
`AuctionSearchTest.java`, but have reverted the file to its original content to appear
more clean. We properly escaped characters when obtaining the XML data for items, and
used a similar time conversion method as we used in Project 2.